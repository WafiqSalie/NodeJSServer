_App = function()
{
	var _App = {
		connect:function()
		{
			var Username = prompt('Please specify a Username');
			if(Username)
			{
				_App.client = io.connect('http://localhost:8001/');
				
				_App.client.on('connect', function() {  
					console.log(Username+' connected');
					_App.client.emit('joinserver', Username);
				});
				
				_App.client.on('updateconsole', function(resp) {  
					var innerHTML = document.getElementById('dvConsole').innerHTML;
					document.getElementById('dvConsole').innerHTML = innerHTML+'<br/>'+resp;
				});
				_App.client.on('userjoined', function(clientID) {  
					console.log(clientID);
					if(!document.getElementById(clientID))
					{
						var NPEl = document.createElement('div');
						NPEl.id = clientID;
						NPEl.style.height = "40px";
						NPEl.style.width = "40px";
						NPEl.style.background = _App.getColour();
						NPEl.style.border = "1px solid black";
						NPEl.style.position = "relative";
						NPEl.classList.add('player');
						document.getElementById('main-field').appendChild(NPEl);
					}
				});
				
				$(document).keydown(function(key){
		
					switch (key.keyCode)
					{
						case 37:  //left
							_App.client.emit('changeposition',JSON.stringify({
								direction:'left',
								clientID:_App.client.io.engine.id
							}));
						break;
						case 38:  //up
							_App.client.emit('changeposition',JSON.stringify({
								direction:'up',
								clientID:_App.client.io.engine.id
							}));
						break;
						case 39:  //right
							_App.client.emit('changeposition',JSON.stringify({
								direction:'right',
								clientID:_App.client.io.engine.id
							}));
						break;
						case 40:  //down
							_App.client.emit('changeposition',JSON.stringify({
								direction:'down',
								clientID:_App.client.io.engine.id
							}));
						break;
					}
				});
				
				
				_App.client.on('positionchanged',function(res)
				{
					var resp = JSON.parse(res);
					switch (resp.direction)
					{
						case 'left':  //left
					var position = $('#'+resp.clientID).position();
						 $('#'+resp.clientID).css('left',position.left -10+'px');
						break;
						case 'up':  //up
					var position = $('#'+resp.clientID).position();
						 $('#'+resp.clientID).css('top',(position.top -130)+'px');
						break;
						case 'right':  //right
					var position = $('#'+resp.clientID).position();
						 $('#'+resp.clientID).css('left',position.left -5+'px');
						break;
						case 'down':  //down
					var position = $('#'+resp.clientID).position();
						 $('#'+resp.clientID).css('top',(position.top -128)+'px');
						break;
					}
				});
				
			}
			else if(Username == "")
			{
				alert("No Username specified.");
			}
		},
		getColour:function()
		{
			var letters = '0123456789ABCDEF'.split('');
			var color = '#';
			for (var i = 0; i < 6; i++ ) {
				color += letters[Math.floor(Math.random() * 16)];
			}
			return color;
		}
	};

	return _App;
}();