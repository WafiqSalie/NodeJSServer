var http = require("http");
var url = require('url');
var fs = require('fs');
var io = require('socket.io');

var server = http.createServer(function(req, res){
    console.log('Connection');
	res.writeHead(200, {"Content-Type": "text/plain"});
    res.end();
});

server.listen(8001);
var socket = io.listen(server); 
var client_sockets = {};
socket.on('connection', function(client){ 

		var ClientAddress = client.handshake.address //+ ":" + client.handshake.port;
		client_sockets[client.id] = client;
		console.log("client "+client.id+" connected.");
	 
		(function ()
        {
            var emit = client.emit;
            client.emit = function ()
            {
                if (arguments[0].toUpperCase() == "HEARTBEAT_CHECK_COMPLETE")
                {
                    client_sockets[client.id].LastHeartbeatComplete = new Date().format("yyyy-MM-dd hh:mm:ss");
                }
                emit.apply(client, arguments);
            };

            var $emit = client.$emit;
            client.$emit = function ()
            {
                client_sockets[client.id].LastActivity = new Date().getTime();
                client_sockets[client.id].LastActivityDescription = arguments[0];
                client_sockets[client.id].DateTimeLastTransact = new Date().format("yyyy-MM-dd hh:mm:ss");
                client_sockets[client.id].LastTransactInput = JSON.stringify(arguments);

                if (arguments[0].toUpperCase() == "HEARTBEAT_CHECK")
                {
                    client_sockets[client.id].LastHeartbeat = new Date().format("yyyy-MM-dd hh:mm:ss");
                }
                $emit.apply(client, arguments);
            };
        })();
	 
    client.on('message', function(msg) { 
		for(var key in client_sockets)
		{
			if(client.id != key)
			{
				var xClient = client_sockets[key];
				xClient.send(msg);
			}
		}
		
	});
	
    client.on('joinserver', function(clientName) { 
		console.log(clientName+' has joined server.');
		client_sockets[client.id].ClientName = clientName;
		for(var key in client_sockets)
		{
			var xClient = client_sockets[key];
			xClient.emit('updateconsole', clientName + ' has joined server.');
			xClient.emit('userjoined', client.id);
		}
	});
	client.on('changeposition', function(req) { 
		for(var key in client_sockets)
		{
			var xClient = client_sockets[key];
			xClient.emit('positionchanged', req);
		}
	});
    client.on('disconnect', function() {  
		console.log('disconnect');
		var CName = client_sockets[client.id].ClientName;
		
		console.log("client "+(CName || client.id)+" disconnect.");
		for(var key in client_sockets)
		{
			var xClient = client_sockets[key];
			xClient.emit('updateconsole', (CName || client.id) + ' has left.');
			xClient.emit('userleft', client.id);
		}
		delete client_sockets[client.id];
	}) ;
}); 